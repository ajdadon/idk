const { red, green, blue, yellow, cyan, yellowBright, } = require('chalk');
const title = String.raw`
  installed                                                                                   
                                                                                                                                              
`;

console.log(green(title))
console.log(``);
console.log(``);
