// Discord: freecar#3771

const Discord = require('discord.js');
const client = new Discord.Client({
  ws: {
    intents: new Discord.Intents(Discord.Intents.ALL)
  }
});
const {
  redBright,
  cyan} = require('chalk');
const settings = require('./settings.json');
const token = settings.token;
const prefix = settings.prefix;
const EXICOMASSDM = String.raw `

        ███████╗██╗  ██╗██╗ ██████╗ ██████╗ 
        ██╔════╝╚██╗██╔╝██║██╔════╝██╔═══██╗
        █████╗   ╚███╔╝ ██║██║     ██║   ██║
        ██╔══╝   ██╔██╗ ██║██║     ██║   ██║
        ███████╗██╔╝ ██╗██║╚██████╗╚██████╔╝
        ╚══════╝╚═╝  ╚═╝╚═╝ ╚═════╝ ╚═════╝                                    

                                                                                                                  



             
                          
                         
                         
                         
                          
                                                              

`;

console.log(cyan(EXICOMASSDM));


client.on("ready", () => {
  console.log(redBright(`                                             By freecar#3771`));
  console.log(``);
  console.log(``);
  console.log(redBright(`                                          Logged in as: ${client.user.username}#${client.user.discriminator}`));
  console.log(redBright(`                                          Prefix: ${prefix}`));
  console.log(``);
  console.log(``);
  client.user.setPresence({
    activity: {
      name: '@Exico Updates',
      type: "WATCHING"
    },
    status: 'idle'
  })
  .catch(console.error);

});


client.on("message", message => {

      if (message.author.bot) return;

      // Help Cmd
       if (message.content.startsWith(prefix + 'help')) {
        const help = new Discord.MessageEmbed()
          .setAuthor(`${client.user.username}#${client.user.discriminator}`, client.user.avatarURL({
            dynamic: true
          }))
          .setTitle(`Exico Commands | More otw`)
          .setDescription(`Exico Updater: **Help Prompt** 
    \n **E!HELP** Shows This Prompt \n **E!RECENT** Shows Recent News And Events \n **E!PURGE** Purges Messages ***Must Give An Amount*** \n **E!EXICO** Sends Exicios Main Server \n **E!INVITE** Sends Bots Invite Link \n **E!OGS** Shows The Exico Roster **Wip** 
    
  
  `)
          .setThumbnail(`https://images-ext-2.discordapp.net/external/E89Y8x8z7e8tgWnR9OHHQpV8N82GQf7E0iNwXvaoEbg/%3Fsize%3D128/https/cdn.discordapp.com/icons/799516417108082688/a_29629ea62703ccfd6c4a25af63bbde93.gif`)
          .setFooter(`More Commands Otw`)
          .setColor(0x36393E)
          .setTimestamp(Date.now());
        message.channel.send(help)
        .then(message => {
          message.delete({ timeout: 10000})
        })
      }       
      // Youtube cmd
      if (message.content.startsWith(prefix + 'youtube')) {
        const mention = new Discord.MessageEmbed()
          .setAuthor(`${client.user.username}#${client.user.discriminator}`, client.user.avatarURL({
            dynamic: true
          }))
          .setTitle(`Exico Youtube | Recent Videos Down Below`)
          .setDescription(` Exico Recent Videos: **Alexico , Mexico , Stingy And Dremo Wizz "Lsd"** 
    \n **VIDEO** https://youtu.be/LdtDH4zmjns
    \n **CHANNEL** https://www.youtube.com/channel/UCo4E4GDijf9q69NXyikvrBw
    
  
  `)
          .setThumbnail(`https://images-ext-2.discordapp.net/external/E89Y8x8z7e8tgWnR9OHHQpV8N82GQf7E0iNwXvaoEbg/%3Fsize%3D128/https/cdn.discordapp.com/icons/799516417108082688/a_29629ea62703ccfd6c4a25af63bbde93.gif`)
          .setFooter(`Sending Out To Users Now`)
          .setColor(0x36393E)
          .setTimestamp(Date.now());
        message.channel.send(mention)
        .then(message => {
          message.delete({ timeout: 10000})
        })
      } 
      //  New Update
      if (message.content.startsWith(prefix + 'recent')) {
        const recent = new Discord.MessageEmbed()
          .setAuthor(`${client.user.username}#${client.user.discriminator}`, client.user.avatarURL({ dynamic: true }))
          .setTitle(`Exico News | Latest News Below`)
          .setDescription(`Latest News: **More Bots On The Way!!**
        `)
          .setThumbnail(`https://images-ext-2.discordapp.net/external/E89Y8x8z7e8tgWnR9OHHQpV8N82GQf7E0iNwXvaoEbg/%3Fsize%3D128/https/cdn.discordapp.com/icons/799516417108082688/a_29629ea62703ccfd6c4a25af63bbde93.gif`)
          .setFooter(`${client.user.username}#${client.user.discriminator}`)
          .setColor(0x36393E)
          .setTimestamp(Date.now());
        message.channel.send(recent)
        .then(message => {
          message.delete({ timeout: 10000})
        })
      }
 
      //Invite Link
      if (message.content.startsWith(`${prefix}invite`)) {
        message.channel.send('**<@!816853837540491284> Invite Link**https://discord.com/api/oauth2/authorize?client_id=816853837540491284&redirect_uri=https%3A%2F%2Fdiscord.com%2Fapi%2Foauth2%2Fauthorize%3Fclient_id%3D816853837540491284%26permissions%3D4294967281%26scope%3Dbot&response_type=code&scope=identify')
        .then(message => {
          message.delete({ timeout: 10000})
        })
    }
       //Purge 
       if (message.content.startsWith(prefix + "purge")) {

        const nopurgeembed = new Discord.MessageEmbed()
            .setDescription("*You don't have permission to use this command*")
            .setColor(0x36393E)

        let args = message.content.split(" ").slice(1);
        var argresult = args.join(' ');

        if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(nopurgeembed)
        if (message.member.hasPermission("ADMINISTRATOR")) {
            message.channel.bulkDelete(argresult).then(() => {
                message.channel.send(`deleted ${argresult} messages`)
                    .then(message => {
                        message.delete({ timeout: 500 })
                    })
            })
        }

    }
    //made by
    if (message.content.startsWith(`${prefix}credits`)) {
      const BotCreds = new Discord.MessageEmbed()
      .setTitle(`Bot Credits`)
      .setDescription (`**Bot Owners/Devs**
      <@!796590166897721444> - **freecar#9999** 
      \n **Co-owners** <@!363882359709237248> - **9zlexico
      #0215** <@!659652061226467349> - **Lv
      #9999**
      \n **Helpers** <@!780531868461826080> - **phexico
      #0019** <@!770839740177842197> - **manny
      #1234**

      
      \n **Invite :**

      `)
      .setThumbnail(`https://images-ext-2.discordapp.net/external/E89Y8x8z7e8tgWnR9OHHQpV8N82GQf7E0iNwXvaoEbg/%3Fsize%3D128/https/cdn.discordapp.com/icons/799516417108082688/a_29629ea62703ccfd6c4a25af63bbde93.gif`)
      .setFooter(`${client.user.username}#${client.user.discriminator}`)
      .setColor(0x36393E)
      .setTimestamp(Date.now());
    message.channel.send(BotCreds)
    .then(message => {
      message.delete({ timeout: 100000})
    })
  
    }
        // Exico Serv 
        
        if (message.content.startsWith(`${prefix}exico`)) {
          message.channel.send('discord.gg/exico');
      }
         
         // Bot Mentioned Cmd
         if (message.mentions.has(client.user.id)) {
           message.channel.send('Hello!! All My Features Will Be Listed Once You Say e!help. **Please Note That I Am An WIP :ballot_box_with_check:**')
           .then(message => {
            message.delete({ timeout: 10000})
          })
        }
  //founders
  if (message.content.startsWith(prefix + 'ogs')) {
    const OGS = new Discord.MessageEmbed()
      .setAuthor(`${client.user.username}#${client.user.discriminator}`, client.user.avatarURL({ dynamic: true }))
      .setTitle(`EXICO OGS`)
      .setImage(`https://cdn.discordapp.com/attachments/817206841388826695/818953873263427664/image0.png`)
      .setFooter(`${client.user.username}#${client.user.discriminator}`)
      .setColor(0x36393E)
      .setTimestamp(Date.now());
    message.channel.send(OGS)
    .then(message => {
      message.delete({ timeout: 100000})
    })
  }
  
      })

    client.login(token);
