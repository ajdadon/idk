const title = String.raw`
launching                                                                                                                                            
`;

console.log(title)

console.log(``);
console.log(`                                          Made by freecar#9999`)
console.log(``);
console.log(``);
